package base;

import java.io.File;
import java.io.IOException;
import java.time.Duration;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import io.github.bonigarcia.wdm.WebDriverManager;
import utils.ReadData;

public class ProjectSpecificMethods {
	public String excelFileName = "";

	private static final ThreadLocal<RemoteWebDriver> remoteWebDriver = new ThreadLocal<RemoteWebDriver>();

	public static ExtentReports extent;
	public static ExtentTest test, node;
	public String testName, testDescription, testCategory, testAuthor; // null

	@BeforeMethod
	public void init() {
		node = test.createNode(testName);
		WebDriverManager.chromedriver().setup();
		// driver = new ChromeDriver();
		// to initialize the driver
		setDriver();
		getDriver().get("http://leaftaps.com/opentaps");
		getDriver().manage().window().maximize();
		getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
	}

	public void reportStep(String stepDesc, String status) throws IOException {

		int randomNumber = takeSnap(); // 535345

		if (status.equalsIgnoreCase("pass")) {
			node.pass(stepDesc,
					MediaEntityBuilder.createScreenCaptureFromPath(".././snaps/img" + randomNumber + ".png").build());
		} else if (status.equalsIgnoreCase("fail")) {
			node.fail(stepDesc,
					MediaEntityBuilder.createScreenCaptureFromPath(".././snaps/img" + randomNumber + ".png").build());
			throw new RuntimeException("Look into the Extent Report for failure details");
		}

	}

	@BeforeSuite
	public void startReport() {
		ExtentHtmlReporter reporter = new ExtentHtmlReporter("./reports/result.html"); // result file
		reporter.setAppendExisting(true);
		extent = new ExtentReports();
		extent.attachReporter(reporter);
	}

	@BeforeClass
	public void testCaseDetails() {
		test = extent.createTest(testName, testDescription);
		test.assignCategory(testCategory);
		test.assignAuthor(testAuthor);

	}

	public int takeSnap() throws IOException {

		int ranNum = (int) (Math.random() * 999999 + 1000000);
		File source = getDriver().getScreenshotAs(OutputType.FILE);
		File target = new File("./snaps/img" + ranNum + ".png"); // dynamic file name img535345.png
		FileUtils.copyFile(source, target);

		return ranNum; // 535345
	}

	@AfterSuite
	public void stopReport() {
		extent.flush();

	}

	// setter method for driver
	public void setDriver() {
		remoteWebDriver.set(new ChromeDriver());
	}

	public RemoteWebDriver getDriver() {
		return remoteWebDriver.get();
	}

	@DataProvider(name = "fetch", indices = 0)
	public String[][] fetchData() throws IOException {
		String[][] data = ReadData.readData(excelFileName);
		return data;
	}

	@AfterMethod
	public void closeBrowser() {
		getDriver().close();
	}

}
