package pages;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import base.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods {

	

	// plural //@FindBys -> AND condition ; @FindAll -> OR condition
	/*
	 * @FindAll( {
	 * 
	 * @FindBy(how = How.CLASS_NAME, using = "inputLogin123"),
	 * 
	 * @FindBy(how = How.XPATH, using = "//input[@type='text']")
	 * 
	 * }
	 * 
	 * ) WebElement eleUsername;
	 */
	
	public LoginPage() {

		PageFactory.initElements(getDriver(), this);

	}

	@FindBy(how = How.ID, using = "username")
	WebElement eleUsername;

	@CacheLookup
	@FindBy(how = How.XPATH, using = "//input[@class='inputLogin']")
	WebElement elePassword;

	@FindBy(how = How.XPATH, using = "//input[@class='decorativeSubmit']")
	WebElement eleLogin;

	// action+ElementName
	public LoginPage enterUsername(String uName) throws InterruptedException, IOException {

		try {
			// getDriver().findElement(By.id("username")).sendKeys(uName);
			eleUsername.sendKeys(uName);
			reportStep(uName + " username is entered", "pass");
		} catch (Exception e) {
			reportStep("username is not entered...." + e, "fail");
		}

		return this;

	}

	public LoginPage enterPassword(String pWord) throws IOException {
		try {
			// getDriver().findElement(By.id("password")).sendKeys(pWord);
			 elePassword.sendKeys(pWord);
			reportStep(pWord + " password is entered", "pass");
		} catch (Exception e) {
			reportStep("password is not entered...." + e, "fail");
		}

		return this;
	}

	public HomePage clickLoginButton() throws IOException {
		try {
			// getDriver().findElement(By.className("decorativeSubmit")).click();
			eleLogin.click();
			reportStep("Login button is clicked", "pass");
		} catch (Exception e) {
			reportStep("Login button is not clicked..." + e, "fail");
		}

		return new HomePage();

	}

	public LoginPage clickLoginButtonForNegativeCredential() throws IOException {
		try {
			// getDriver().findElement(By.className("decorativeSubmit")).click();
			eleLogin.click();
			reportStep("Login button is clicked", "pass");
		} catch (Exception e) {
			reportStep("Login button is not clicked..." + e, "fail");
		}

		return this;

	}

}
