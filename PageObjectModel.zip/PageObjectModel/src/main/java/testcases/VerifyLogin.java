package testcases;

import java.io.IOException;
import java.time.Duration;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import io.github.bonigarcia.wdm.WebDriverManager;
import pages.HomePage;
import pages.LoginPage;
import utils.ReadData;

public class VerifyLogin extends ProjectSpecificMethods {
		
	
	@BeforeTest
	public void setup() {
		excelFileName = "Login";
		testName = "Verify Login";
		testDescription = "Login with positive credential";
		testCategory = "smoke";
		testAuthor = "Hari";
				
	}

	
	@Test(dataProvider="fetch")
	public void runLogin(String username, String password) throws InterruptedException, IOException {
		System.out.println(getDriver());
		LoginPage lp = new LoginPage();
		lp.enterUsername(username)
		.enterPassword(password)
		.clickLoginButton()
		.verifyHomePage();
		
	}

}
